public class Cachorro extends Animal {

    String latido;
}
