public class Animal {

    /**
    /*Animal
     */
    public String nome;
    public int idade;

}
