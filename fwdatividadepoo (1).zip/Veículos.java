public class Veículos {
    
    String TamanhoPorte;
    String modelo;
}
