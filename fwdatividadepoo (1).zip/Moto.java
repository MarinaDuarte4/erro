public class Moto extends Veículos {

    int qtdRodas;
    int qtdCilindrade;
    int km;
}
