public class Carro extends Veículos {

    int qtdPortas;
    int qtdRodas;
    String convecivel;
}
