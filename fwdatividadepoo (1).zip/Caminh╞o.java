public class Caminhão extends Veículos {
    
    int qtdRodas;
    String tipoCombustivel;
    String CNH;
}
