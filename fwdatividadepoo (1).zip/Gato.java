public class Gato extends Animal {
    
    String miado;
}
